<?php
@ob_start();
@session_start();
error_reporting(0);
//$siteUrl ='http://localhost/mycdrhelp-latest/';
$siteUrl ='https://www.mycdrhelp.com/';
?>