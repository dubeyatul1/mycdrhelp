<?php  
@ob_start();
@session_start();
error_reporting(0);
$siteUrl='https://www.mycdrhelp.com/';
//$siteUrl='http://localhost/my-cdr-help/';
?>