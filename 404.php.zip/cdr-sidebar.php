

<!--Start Sidebar Section-->

<div class="sidebar-container">
<div class="form-con1">        
      <div class="col-md-12 pull-right">
                <h3>Get Free Consultation</h3>
                <form>
                <div class="frm-inner2">                    
                <input name="name" type="text" placeholder="Name *"> 
                <input name="email" type="text" placeholder="E-Mail *"> 
                <input name="mobile" type="text" placeholder="Phone *">
                   <select id="requirement">
                      <option>Requirement*</option>
                      <option>Full CDR Report</option>
                      <option>Career Episode</option>
                      <option>Summary Statement</option>
                      <option>CDR Review</option>
                      <option>RPL Report</option>
                      <option>KA02 Report</option>
                   </select>      
                <textarea name="msg" placeholder="Write a Message *" class="txtareas"></textarea> 
                <button type="button" name="submit" class="submit_btn" id="isvalidcontact" aria-hidden="true"> Submit</button>
                <div id="success" class="alert alert-success hide" role="alert" style="position: fixed; width: auto;">Your enquiry successfully send.</div>
              </div>  
              </form>                
      </div>
      </div>
       </div>

       
       
     <!--OUR AMAZING FEATURES--> 
     <div class="col-sm-12 pd">
          <div class="right_part">
            <h4> Our Amazing Features</h4>
            <ul class="w-choose-us">
                <li>EA Assessed Engineers as CDR Writers</li>
                <li>10+ Years of Experience</li>
                <li>Australia Based Company</li>
                <li>All Engineering Disciplines</li><li>100% Success Rate with EA</li><li>100% Plagiarism Free Report/Turnitin</li>
                <li>Unlimited Free Modification/Corrections</li>
                <li>Negative Assessment? Get Refund within 2 hours</li>
                <li>24*7 Live Chat, Phone Call and WhatsApp Facility</li>
                <li>Direct Conversation with The CDR Experts</li>
                <li>Beat the value offer</li>
                <li>Complete CDR Before the Agreed Due Date</li>
            </ul>
          </div>
       </div> 
       
     <!--OUR PREMIUM SERVICES-->
      <div class="col-sm-12 pd">
          <div class="right_part">
            <h4>Our Premium Services</h4>
             <ul class="rigt_menu">
             <li><a href="<?php echo $siteUrl;?>cdr-engineers-australia"><i class="fa fa-angle-double-right"></i>  CDR for Engineers Australia </a></li>
             <li><a href="<?php echo $siteUrl;?>career-episode"> <i class="fa fa-angle-double-right"></i> Career Episode Help</a> </li>
             <li><a href="<?php echo $siteUrl;?>cdr-plagiarism-checking"> <i class="fa fa-angle-double-right"></i> CDR Plagiarism Check</a> </li>
             <li><a href="<?php echo $siteUrl;?>cdr-reviewing"> <i class="fa fa-angle-double-right"></i> CDR Reviewing Help</a> </li>
             <li><a href="<?php echo $siteUrl;?>cpd-writing"> <i class="fa fa-angle-double-right"></i> CPD Writing Help</a> </li>
             <li><a href="<?php echo $siteUrl;?>curriculum-vitae"> <i class="fa fa-angle-double-right"></i> Curriculum Vitae</a> </li>
             <li><a href="<?php echo $siteUrl;?>rpl-writing-services">  <i class="fa fa-angle-double-right"></i> RPL for ACS</a></li>
             <li><a href="<?php echo $siteUrl;?>KA02-report">  <i class="fa fa-angle-double-right"></i> Engineering New Zealand KA02 Report Help</a></li>
             <li><a href="<?php echo $siteUrl;?>skilled-nominated-visas-northern-territory-statement"> <i class="fa fa-angle-double-right"></i> Commitment to the Northern Territory (NT) Statement</a></li>
             <li><a href="<?php echo $siteUrl;?>NER-Australia"> <i class="fa fa-angle-double-right"></i> NER Australia</a></li>
             <li><a href="<?php echo $siteUrl;?>ITP-evidence-document-CITPNZ"> <i class="fa fa-angle-double-right"></i> ITP Evidence Document CITPNZ</a></li>
             <li><a href="<?php echo $siteUrl;?>stage-2-competency-assessment-service"> <i class="fa fa-angle-double-right"></i> Stage-2 Assessment</a></li>
             <li><a href="<?php echo $siteUrl;?>chartered-member-competence-commitment-report"> <i class="fa fa-angle-double-right"></i> Competence and Commitment report (IChemE)</a></li>
             <li><a href="<?php echo $siteUrl;?>competency-based-assessment-CBA-APEGS"> <i class="fa fa-angle-double-right"></i> Competency-Based Assessment(CBA)-APEGS</a></li>
             <li><a href="<?php echo $siteUrl;?>IMarEST-CEng-report-help"> <i class="fa fa-angle-double-right"></i> IMAREST CEng UK Council</a></li>
             <li><a href="<?php echo $siteUrl;?>IEPNG-CBA-report-help"> <i class="fa fa-angle-double-right"></i> IEPNG Papua New Guinea</a></li>
             <li><a href="<?php echo $siteUrl;?>APEGBC-Report"> <i class="fa fa-angle-double-right"></i> APEGBC Canada</a></li>
             <li><a href="<?php echo $siteUrl;?>business-plan-new-innovator-visa-TIER-1-UK"> <i class="fa fa-angle-double-right"></i> Business Plan for New Innovator VISA (TIER 1 UK)</a></li>
             <li><a href="<?php echo $siteUrl;?>work-experience-reports-for-LCIBSE-Eng-Tech"> <i class="fa fa-angle-double-right"></i> Work Experience Reports for LCIBSE Eng Tech</a></li>
             <li><a href="<?php echo $siteUrl;?>chartered-institution-of-building-services-engineers-CIBSE-CENG"> <i class="fa fa-angle-double-right"></i> Chartered Institution of Building Services Engineers (CIBSE CENG)</a></li>
			 <li><a href="<?php echo $siteUrl;?>UK-spec-UK-standard-professional-engineering-competence"> <i class="fa fa-angle-double-right"></i> CEng Professional Report for UK-SPEC</a></li>
			 <li><a href="<?php echo $siteUrl;?>chartered-engineer-CEng-IEng-VIA-TRR"> <i class="fa fa-angle-double-right"></i> Chartered Engineer (CEng) and IEng via TRR</a></li>
			 <li><a href="<?php echo $siteUrl;?>APEGBC-Report"> <i class="fa fa-angle-double-right"></i> APEGBS P.Eng Competency Report</a></li>
			 <li><a href="<?php echo $siteUrl;?>proffesional-registration-via-IET"> <i class="fa fa-angle-double-right"></i> Professional Registeration via IET</a></li>
            </ul>
          </div>
       </div> 
       
     <!--EA APPROVED CDR SAMPLES-->
      <div class="col-sm-12 pd">
          <div class="right_part">
            <h4>EA Approved CDR Samples</h4>
            <ul class="rigt_menu">
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-engineering-manager">  <i class="fa fa-angle-double-right"></i> Engineering Manager</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-career-report-episode-chemical-engineer"> <i class="fa fa-angle-double-right"></i> Chemical Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-materials-engineering"> <i class="fa fa-angle-double-right"></i> Materials Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-civil-engineers"> <i class="fa fa-angle-double-right"></i> Civil Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-geotechnical-engineers"> <i class="fa fa-angle-double-right"></i> Geotechnical Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-structural-engineers"> <i class="fa fa-angle-double-right"></i> Structural Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-career-episode-planners-transport-engineers"> <i class="fa fa-angle-double-right"></i> Transport Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-electrical-engineers"> <i class="fa fa-angle-double-right"></i> Electrical Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-electronics-engineers"> <i class="fa fa-angle-double-right"></i> Electronics Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-industrial-engineers"> <i class="fa fa-angle-double-right"></i> Industrial Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-mechanical-engineers"> <i class="fa fa-angle-double-right"></i> Mechanical Engineer</a></li>
                  <li><a href="<?php echo $siteUrl;?>cdr-sample-for-production-plant-engineer"> <i class="fa fa-angle-double-right"></i> Production or Plant Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-mining-engineers"> <i class="fa fa-angle-double-right"></i> Mining Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-petroleum-engineers"> <i class="fa fa-angle-double-right"></i> Petroleum Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-aeronautical-engineers"> <i class="fa fa-angle-double-right"></i> Aeronautical Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-agricultural-engineers"> <i class="fa fa-angle-double-right"></i> Agricultural Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-biomedical-engineers"> <i class="fa fa-angle-double-right"></i> Biomedical Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-engineering-technologist"> <i class="fa fa-angle-double-right"></i> Engineering Technologist</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-environmental-engineers"> <i class="fa fa-angle-double-right"></i> Environmental Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-architectural-engineer"> <i class="fa fa-angle-double-right"></i> Architectural Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-mechatronics-engineer"> <i class="fa fa-angle-double-right"></i> Mechanotronics Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-engineering-professionals"> <i class="fa fa-angle-double-right"></i> Engineer Professionals (nec)</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-telecommunication-engineers"> <i class="fa fa-angle-double-right"></i> Telecommunications Engineer</a></li>
                 
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-telecommunications-network-engineers"> <i class="fa fa-angle-double-right"></i> Telecommunications Network Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-civil-engineering-draftsperson"> <i class="fa fa-angle-double-right"></i> Civil Engineering Draftsperson</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-electrical-engineering-draftsperson"> <i class="fa fa-angle-double-right"></i> Electrical Engineering Draftsperson</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-telecommunications-field-engineers"> <i class="fa fa-angle-double-right"></i> Telecommunications Field Engineer </a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-computer-network-systems-engineer"> <i class="fa fa-angle-double-right"></i> Computer Network &amp; Systems Engineer</a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-electrical-engineering-technician"> <i class="fa fa-angle-double-right"></i> Electrical Engineering Technician </a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-for-civil-engineering-technologist"> <i class="fa fa-angle-double-right"></i> Civil Engineering Technologist </a></li>
                 <li><a href="<?php echo $siteUrl;?>cdr-sample-career-episode-planners-telecommunication-network"> <i class="fa fa-angle-double-right"></i> Telecommunication Network Planner </a></li>
              <li><a href="<?php echo $siteUrl;?>cdr-sample-career-episode-planners-telecommunication-technical-officer"> <i class="fa fa-angle-double-right"></i> Telecommunication Technical Officer</a></li>
            </ul>
          </div>
       </div> 
       
       <div class="inner-cnt-abt"><img src="images/Secure-Payment.png" alt=""></div> 
       <div class="inner-cnt-abt"><img src="images/CDR-writing-data-flow.png" alt=""></div> 
       <div class="inner-cnt-abt"><img src="images/mycdrhelp-cdr-report.png" alt=""></div> 
       <div class="inner-cnt-abt"><img src="images/MyCDRHelp-CPD-writing-services.png" alt=""></div> 
       <div class="inner-cnt-abt"><img src="images/Privacy-security.png" alt=""></div>   
           
</div>

<!--End Sidebar Section-->
