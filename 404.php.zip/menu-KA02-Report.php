<div class="col-md-3 no-padding pull-right" data-aos="zoom-in"> 

<p>&nbsp;</p>
<div class="right_part">
<h3>Our Premium Services</h3>
<ul class="rigt_menu">
 <li><a href="<?php echo $baseUrl;?>"> CDR for Engineers Australia <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>rpl-writing-services">  RPL for ACS  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>skilled-nominated-visas-northern-territory-statement"> Commitment to the Northern Territory (NT) Statement <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>NER-Australia"> NER Australia <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-member-competence-commitment-report"> Competence and Commitment report (IChemE) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>ITP-evidence-document-CITPNZ"> ITP Evidence Document CITPNZ <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>KA02-report"> Engineering New Zealand KA02 Report Help  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>competency-based-assessment-CBA-APEGS"> Competency-Based Assessment(CBA)-APEGS <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li> 
 <li><a href="<?php echo $baseUrl;?>IMarEST-CEng-report-help"> IMarEST CEng UK Council <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>UK-spec-UK-standard-professional-engineering-competence"> CEng Professional Report for UK-SPEC <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-engineer-CEng-IEng-VIA-TRR"> Chartered Engineer (CEng) and IEng VIA TRR <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>IEPNG-CBA-report-help"> IEPNG Papua New Guinea <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>APEGBC-Report"> APEGBS P.Eng Competency Report <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>APEGS-work-experience-reporting-help"> APEGS Work Experience Reporting <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>business-plan-new-innovator-visa-TIER-1-UK"> Business Plan for New Innovator VISA (TIER 1 UK) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>work-experience-reports-for-LCIBSE-Eng-Tech"> Work Experience Reports for LCIBSE Eng Tech <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>proffesional-registration-via-IET"> Proffesional Registration VIA IET <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-institution-of-building-services-engineers-CIBSE-CENG"> Chartered Institution of Building Services Engineers (CIBSE CENG) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>stage-2-competency-assessment-service"> Stage-2 Assessment <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
</ul>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<h3> Our Amazing Features</h3> 
	 <div class="clearfix"></div>
<ol class="w-choose-us">
<li>IPENZ Assessed Professionals as KA02 Writers
<li>10+ Years of Domain Experience
<li>Top Notch Native Experts from New Zealand
<li>All Engineering Disciplines
<li>100% Success Rate with Engineers New Zealand
<li>100% Plagiarism Free Report/Turnitin
<li>Unlimited Free Modification/Corrections
<li>Negative Assessment? Get Full Refund within 2 hours
<li>24*7 Live Chat, Phone Call and WhatsApp Facility
<li>Direct Conversation with The KA02 Experts
<li>Pay only 75% Advance and 25% after Positive Assessment
<li>Beat the value offer
<li>Complete KA02 Report Before the Agreed Due Date
</ol>
 <p>&nbsp;</p>
<p>&nbsp;</p>
<h3> Top 10 reasons to choose us</h3> 
	 <div class="clearfix"></div>
<ol class="w-choose-us">
<li>100% Satisfaction Guaranteed</li>
<li>Experienced CDR Expert Writers</li>
<li>100%  Approval Rate</li>
<li>Three Carrier Episodes</li>
<li>Summary Statements</li>
<li>CPD Report</li>
<li>Free Modification</li>
<li>Free Turnitin Report</li>
<li>24 x 7 Availability</li>
<li>On Time Delivery</li>
<li>Team of Engineers</li>
 </ol>

<p>&nbsp;</p>
  <p>&nbsp;</p>
<h3>Working Methodology</h3>		   
<picture>
  <source type="image/webp" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.webp">
  <source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.png">
  <img data-src="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.png" alt="CDR Writing Help" class="img-responsive lazyload">
</picture>
    
</div>
    </div> 