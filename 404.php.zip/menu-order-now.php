<div class="col-md-3 no-padding pull-right" data-aos="zoom-in"> 

<p>&nbsp;</p>

<div class="right_part">
<h3> Our Amazing Features</h3> 
	 <div class="clearfix"></div>
<ol class="w-choose-us">
<li>EA Assessed Engineers as CDR Writers
<li>10+ Years of Experience
<li>Australia Based Company
<li>All Engineering Disciplines
<li>100% Success Rate with EA
<li>100% Plagiarism Free Report/Turnitin
<li>Unlimited Free Modification/Corrections
<li>Negative Assessment? Get Full Refund within 2 hours
<li>24*7 Live Chat, Phone Call and WhatsApp Facility
<li>Direct Conversation with The CDR Experts
<li>Pay only 75% Advance and 25% after Positive Assessment (For Fast Track)
<li>Beat the value offer
<li>Complete CDR Before the Agreed Due Date
 </ol>
</div>

    </div> 