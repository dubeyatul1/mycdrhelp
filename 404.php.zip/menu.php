<div class="col-md-3 no-padding pull-right" data-aos="zoom-in"> 

<p>&nbsp;</p>

<div class="right_part">
<h3> Our Amazing Features</h3> 
	 <div class="clearfix"></div>
<ol class="w-choose-us">
<li>EA Assessed Engineers as CDR Writers
<li>10+ Years of Experience
<li>Australia Based Company
<li>All Engineering Disciplines
<li>100% Success Rate with EA
<li>100% Plagiarism Free Report/Turnitin
<li>Unlimited Free Modification/Corrections
<li>Negative Assessment? Get Full Refund within 2 hours
<li>24*7 Live Chat, Phone Call and WhatsApp Facility
<li>Direct Conversation with The CDR Experts
<li>Pay only 75% Advance and 25% after Positive Assessment (For Fast Track)
<li>Beat the value offer
<li>Complete CDR Before the Agreed Due Date
 </ol>
</div>


<p>&nbsp;</p>
<div class="right_part">
<h3>Our Premium Services</h3>
<ul class="rigt_menu">
 <li><a href="<?php echo $baseUrl;?>"> CDR for Engineers Australia <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>career-episode"> Career Episode Help <i class="fa fa-angle-double-right" aria-hidden="true"></i></a> </li>
 <li><a href="<?php echo $baseUrl;?>cdr-plagiarism-checking"> CDR Plagiarism Check <i class="fa fa-angle-double-right" aria-hidden="true"></i></a> </li>
 <li><a href="<?php echo $baseUrl;?>cdr-reviewing"> CDR Reviewing Help <i class="fa fa-angle-double-right" aria-hidden="true"></i></a> </li>
 <li><a href="<?php echo $baseUrl;?>cpd-writing"> CPD Writing Help <i class="fa fa-angle-double-right" aria-hidden="true"></i></a> </li>
 <li><a href="<?php echo $baseUrl;?>curriculum-vitae"> Curriculum Vitae <i class="fa fa-angle-double-right" aria-hidden="true"></i></a> </li>
 <li><a href="<?php echo $baseUrl;?>rpl-writing-services">  RPL for ACS  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>KA02-report">  Engineering New Zealand KA02 Report Help  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>skilled-nominated-visas-northern-territory-statement"> Commitment to the Northern Territory (NT) Statement <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>NER-Australia"> NER Australia <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-member-competence-commitment-report"> Competence and Commitment report (IChemE) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>ITP-evidence-document-CITPNZ"> ITP Evidence Document CITPNZ <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>competency-based-assessment-CBA-APEGS"> Competency-Based Assessment(CBA)-APEGS <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>IMarEST-CEng-report-help"> IMarEST CEng UK Council <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>UK-spec-UK-standard-professional-engineering-competence"> CEng Professional Report for UK-SPEC <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-engineer-CEng-IEng-VIA-TRR"> Chartered Engineer (CEng) and IEng VIA TRR <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>IEPNG-CBA-report-help"> IEPNG Papua New Guinea <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>APEGBC-Report"> APEGBS P.Eng Competency Report <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>APEGS-work-experience-reporting-help"> APEGS Work Experience Reporting <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>business-plan-new-innovator-visa-TIER-1-UK"> Business Plan for New Innovator VISA (TIER 1 UK) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>work-experience-reports-for-LCIBSE-Eng-Tech"> Work Experience Reports for LCIBSE Eng Tech <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>proffesional-registration-via-IET"> Proffesional Registration VIA IET <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>chartered-institution-of-building-services-engineers-CIBSE-CENG"> Chartered Institution of Building Services Engineers (CIBSE CENG) <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>stage-2-competency-assessment-service"> Stage-2 Assessment <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
</ul>
</div>

<p>&nbsp;</p>




		   <div class="right_part">
		   <h3>EA Approved CDR Samples</h3>
<ul class="rigt_menu">
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-engineering-manager"> Engineering Manager <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-career-report-episode-chemical-engineer"> Chemical Engineer  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-materials-engineering"> Materials Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-civil-engineers"> Civil Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-geotechnical-engineers"> Geotechnical Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-structural-engineers"> Structural Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-career-episode-planners-transport-engineers"> Transport Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-electrical-engineers"> Electrical Engineer  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-electronics-engineers"> Electronics Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-industrial-engineers"> Industrial Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-mechanical-engineers"> Mechanical Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
  <li><a href="<?php echo $baseUrl;?>cdr-sample-for-production-plant-engineer"> Production or Plant Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-mining-engineers"> Mining Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-petroleum-engineers"> Petroleum Engineer  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-aeronautical-engineers"> Aeronautical Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-agricultural-engineers"> Agricultural Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-biomedical-engineers"> Biomedical Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-engineering-technologist"> Engineering Technologist <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-environmental-engineers"> Environmental Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-architectural-engineer"> Architectural Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-mechatronics-engineer"> Mechanotronics Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-engineering-professionals"> Engineer Professionals (nec)  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-telecommunication-engineers"> Telecommunications Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-telecommunications-network-engineers"> Telecommunications Network Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-civil-engineering-draftsperson"> Civil Engineering Draftsperson <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-electrical-engineering-draftsperson"> Electrical Engineering Draftsperson  <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-telecommunications-field-engineers"> Telecommunications Field Engineer <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-computer-network-systems-engineer"> Computer Network & Systems Engineer<i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-electrical-engineering-technician"> Electrical Engineering Technician <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 <li><a href="<?php echo $baseUrl;?>cdr-sample-for-civil-engineering-technologist"> Civil Engineering Technologist <i class="fa fa-angle-double-right" aria-hidden="true"></i></a></li>
 </ul>
 </div>



<div class="right_part">
 
 <picture>
					<source type="image/webp" data-srcset="<?php echo $baseUrl;?>images/Secure-Payment.webp">
					<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>images/Secure-Payment.png">
					<img data-src="<?php echo $baseUrl;?>images/Secure-Payment.png" alt="Payment Secure by MyCDRHelp" class="img-responsive lazyload">
				</picture>
 
 <p>&nbsp;</p>

 <div class="home-page-right-sect">
      <h2>Our Top Engineering Experts</h2>
       <div class="home-profile-header">
          <div class="row">
            <div class="col-md-3 col-xs-3">
              <div class="home-profile-image">
				<picture>
					<source type="image/webp" data-srcset="<?php echo $baseUrl;?>img/img1.webp">
					<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>img/img1.png">
					<img data-src="<?php echo $baseUrl;?>img/img1.png" alt="CDR Writing Help" class="img-responsive lazyload">
				</picture>
					
			  </div>
            </div>
            <div class="col-md-9 col-xs-9">
              <div class="home-profile-content"><h4>Amelia </h4>
              <p>Master and specialization in Aeronautical Engineers</p>
              <div>
                <a href="<?php echo $baseUrl;?>order-now" class="btn btn-primary btn-round-1">Hire Me </a>
              </div></div>
            </div>
          </div>
        </div>
        
        <div class="home-profile-header">
          <div class="row">
            <div class="col-md-3 col-xs-3">
              <div class="home-profile-image"> 
				<picture>
					<source type="image/webp" data-srcset="<?php echo $baseUrl;?>img/img2.webp">
					<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>img/img2.png">
					<img data-src="<?php echo $baseUrl;?>img/img2.png" alt="CDR Writing Help" class="img-responsive lazyload">
				</picture></div>
            </div>
            <div class="col-md-9 col-xs-9">
              <div class="home-profile-content"><h4>Oliver </h4>
              <p>Master and specialization in Agricultural Engineers</p>
              <div>
                <a href="<?php echo $baseUrl;?>order-now" class="btn btn-primary btn-round-1">Hire Me </a>
              </div></div>
            </div>
          </div>
        </div>
        
        <div class="home-profile-header">
          <div class="row">
            <div class="col-md-3 col-xs-3">
              <div class="home-profile-image"> 
				<picture>
					<source type="image/webp" data-srcset="<?php echo $baseUrl;?>img/img3.webp">
					<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>img/img3.png">
					<img data-src="<?php echo $baseUrl;?>img/img3.png" alt="CDR Writing Help" class="img-responsive lazyload">
				</picture> 
			  </div>
            </div>
            <div class="col-md-9 col-xs-9">
              <div class="home-profile-content"><h4>Amelia </h4>
              <p>Master and specialization in Aeronautical Engineers</p>
              <div>
                <a href="<?php echo $baseUrl;?>order-now" class="btn btn-primary btn-round-1">Hire Me </a>
              </div></div>
            </div>
          </div>
        </div>
        
        <div class="home-profile-header">
          <div class="row">
            <div class="col-md-3 col-xs-3">
              ``<div class="home-profile-image">
					<picture>
						<source type="image/webp" data-srcset="<?php echo $baseUrl;?>img/img4.webp">
						<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>img/img4.png">
						<img data-src="<?php echo $baseUrl;?>img/img4.png" alt="CDR Writing Help" class="img-responsive lazyload">
					</picture>
				</div>
            </div>
            <div class="col-md-9 col-xs-9">
              <div class="home-profile-content"><h4>Adam Smith </h4>
              <p>Master and specialization in Bio-Medical Engineers</p>
              <div>
                <a href="<?php echo $baseUrl;?>order-now" class="btn btn-primary btn-round-1">Hire Me </a>
              </div></div>
            </div>
          </div>
        </div>
        
        <div class="home-profile-header">
          <div class="row">
            <div class="col-md-3 col-xs-3">
              <div class="home-profile-image"> <picture>
		<source type="image/webp" data-srcset="<?php echo $baseUrl;?>img/img5.webp">
		<source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>img/img5.png">
		<img data-src="<?php echo $baseUrl;?>img/img5.png" alt="CDR Writing Help" class="img-responsive lazyload">
	</picture></div>
            </div>
            <div class="col-md-9 col-xs-9">
              <div class="home-profile-content"><h4>Adam Thomas </h4>
              <p>Master and specialization in Chemical Engineers</p>
              <div>
                <a href="<?php echo $baseUrl;?>order-now" class="btn btn-primary btn-round-1">Hire Me </a>
              </div></div>
            </div>
          </div>
        </div>
      <center><a class="view-all-exp" href="<?php echo $baseUrl;?>top-engineering-experts">view All Experts</a> </center>   
      </div> 
<p>&nbsp;</p>
 
  <picture>
  <source type="image/webp" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-CPD-writing-services.webp">
  <source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-CPD-writing-services.png">
  <img data-src="<?php echo $baseUrl;?>images/MyCDRHelp-CPD-writing-services.png" alt="CPD Writing Help" class="img-responsive lazyload">
</picture>
<p>&nbsp;</p>
<a href="<?php echo $baseUrl;?>order-now"><picture>
  <source type="image/webp" data-srcset="<?php echo $baseUrl;?>images/Privacy-security.webp">
  <source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>images/Privacy-security.png">
  <img data-src="<?php echo $baseUrl;?>images/Privacy-security.png" alt="CDR Writing Help" class="img-responsive lazyload">
</picture></a>
<p>&nbsp;</p>
 <p>&nbsp;</p>
<h3>Working Methodology</h3>		   
<picture>
  <source type="image/webp" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.webp">
  <source type="image/jpeg" data-srcset="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.png">
  <img data-src="<?php echo $baseUrl;?>images/MyCDRHelp-how-it-works.png" alt="CDR Writing Help" class="img-responsive lazyload">
</picture>
</div>    
    </div> 